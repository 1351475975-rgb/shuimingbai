<!-- platform: shipinhao | mode: generate_only | risk: 5 -->

口播提纲：开场热点→痛点→三点建议→引导关注