<!-- platform: douyin | mode: generate_only | risk: 5 -->

第1页：企业接AI最难的不是技术
第2页：是选哪家API
第3页：看价格、稳定性、接口统一